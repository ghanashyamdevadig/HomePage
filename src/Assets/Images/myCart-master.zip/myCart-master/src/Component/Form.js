// import React from 'react'

// import './Form.css'

// export default function Form() {
//   return (
//     <div className='main-container'>
//         <div className="img-cntr">
//            <img
//             className="img"
//              src={Images}
//               alt=""
//            />
//      </div>
//      <div>

//      </div>
// </div>
//   )
// }
